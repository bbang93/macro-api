"""Train Macro API - FastAPI backend for SRT/KTX booking automation."""

__version__ = "1.0.0"
